package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrovaLavoroApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrovaLavoroApplication.class, args);
    }
}
